/*
 * The following parts are Copyright of the individual authors.
 *
 * Copyright 2005 Francesco Saverio Giudice <info@fsgiudice.com>
 *    README file explaining howto compile FreeImage library
 *
 * See COPYING.txt for licensing terms.
 *
 */

FreeImage Library is a porting to xHarbour of famous FreeImage Project library.

FreeImage Project's web site is http://freeimage.sourceforge.net/

USAGE
=====

Add hbfimage.hbc to your hbmk2 project.

DOCUMENTATION
=============

Look at doc folder for help files.
Last FreeImage pdf manual is downloadable from http://freeimage.sourceforge.net/download.html

SAMPLES
=======

For samples look at tests dir.
fitest.prg is an API test application.
